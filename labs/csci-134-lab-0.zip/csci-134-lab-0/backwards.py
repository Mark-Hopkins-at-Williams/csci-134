name = input("What is your name? ")
result = ''.join(reversed(name))
print("Your name backwards is {}.".format(result))